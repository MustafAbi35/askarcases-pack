# Kasa Sistemi - Skin Resource Pack

Bu paket, `crates.yml` içindeki 16 nadir/destansı/efsanevi eşyaya **gerçek 3D
model** (cuboid/element tabanlı geometri) uygular — düz bir 2D ikon değil,
Minecraft'ın kendi araçları gibi elde/yerde/envanterde hacimli görünen özel
şekiller. Sıradan eşyalara skin uygulanmadı (istendiği gibi).

Her eşya kendi kategorisine uygun bir 3D gövdeden oluşur (kılıç = blade +
guard + hilt + pommel; balta = head + handle; zırh parçaları = kalın
paneller vb.) ve iki renk katmanı (`primary` ana renk, `secondary` sap/kenar
rengi) ile temaya göre boyanır.

## 1. Sunucuya Uygulama

**SaganNetwork panelinde genelde iki yöntem olur:**

**A) Panel üzerinden yükleme (varsa)**
- Panelde "Resource Pack" / "Doku Paketi" sekmesini bulun
- Bu zip dosyasını doğrudan yükleyin

**B) URL ile (server.properties)**
- Bu zip'i bir dosya barındırma servisine yükleyin (örn. kendi web siteniz,
  Dropbox direct-link, GitHub Releases) ve linkini alın
- `server.properties` dosyasında:
  ```
  resource-pack=https://.../kasasistemi_resourcepack.zip
  resource-pack-sha1=<zip dosyasının SHA1 hash'i>
  require-resource-pack=false
  ```
- SHA1 hash'i almak için: `sha1sum kasasistemi_resourcepack.zip` (Linux/Mac)
  veya PowerShell'de `Get-FileHash -Algorithm SHA1 dosya.zip`

## 2. Kendi Tasarımlarınızı Eklemek / Değiştirmek

Her skin üç dosyadan oluşur, ID'yi (ör. `4001`) hepsinde eşleştirin:

- `assets/minecraft/textures/item/custom/4001_primary.png` → ana renk/doku (16x16)
- `assets/minecraft/textures/item/custom/4001_secondary.png` → sap/kenar rengi (16x16)
- `assets/minecraft/models/item/custom/4001.json` → 3D gövde (elements) + hangi
  dokuların hangi yüzeye uygulandığı

Renkleri değiştirmek için sadece PNG dosyalarını düzenlemeniz yeterli — 3D
şekli değiştirmek isterseniz `.json` içindeki `elements` listesindeki
`from`/`to` koordinatlarını (0-16 arası, Minecraft model birimi) düzenleyin.
Daha görsel/kolay düzenleme için **Blockbench** (blockbench.net, ücretsiz,
Minecraft item model içe/dışa aktarmayı destekler) şiddetle önerilir — bu
JSON dosyalarını doğrudan Blockbench'te açıp düzenleyebilirsiniz.

## 3. Yeni Skin Eklerken Dikkat

`crates.yml`'e yeni bir ödül eklediğinizde (`model-data: XXXX`), bu resource
pack'e de karşılığını eklemeniz gerekir, yoksa oyuncular varsayılan (düz)
eşya görünümünü görür:

1. `assets/minecraft/textures/item/custom/XXXX.png` dokusunu ekleyin
2. `assets/minecraft/models/item/custom/XXXX.json` dosyasını ekleyin (var olan
   bir tanesini kopyalayıp `layer0` satırındaki ID'yi değiştirin)
3. İlgili taban eşyanın override dosyasına (`models/item/diamond_sword.json`
   gibi) yeni bir `predicate/custom_model_data` girişi ekleyin

## 4. Not: Zırh ve Kalkan Sınırlaması

Bu paketteki zırh parçaları (miğfer, göğüslük vb.) sadece **envanterdeki
ikonu** değiştirir; oyuncu üzerine giydiğinde 3D zırh modelinin dokusu
değişmeyebilir (Minecraft 1.20+ "armor trim" sistemi ayrı bir konu ve daha
gelişmiş bir kurulum gerektirir). Kalkan da benzer bir sınırlamaya sahiptir.
Kılıç, kazma, balta, kürek, çapa ve olta için skin değişimi elde/yerde tam
görünür.
